package com.pensareluis.Holamundo.constant;

/**
 * @author Jorge Álvarez
 * @version 1.0 - 2018/03/26
 */
public class ViewConstant {
    public static final String CONTACT_FORM="contactform";
    public static final String CONTACTS="contacts";
    public static final String LOGIN="login";



}
